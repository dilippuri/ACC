 1. Enter the number of iterations. (Number of testcase you want to enter)

2. Input two integers in the format: 'x'  'a' (base,  exponent).

3. Output is result of x^a and time requires to calculate the result for both general method and using Binary Exponent Algorithm.

4. Realtime Comparison between general method and Binary Exponent procedure is available in Output.docx.