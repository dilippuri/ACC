1. Input the size of array.

2. Input the array elements.

3. Output is number of Inversion present in an array.

4. inversion.c is implemented using nested for loop, thus take O(n^2).
   inversionM.c is implemented using merge() procedure, it takes O(n.logn).